================================================
  REVIVAL CHOIR SONGS - Build Your Android APK
  Using GitHub Actions (FREE, ~10 minutes)
================================================

WHY GITHUB ACTIONS?
  - Android SDK already installed on their servers (no 2-hour downloads)
  - Free for public repositories
  - Builds reliably in 10-15 minutes
  - APK downloads easily when done
  - No session timeouts like Google Colab


STEP-BY-STEP INSTRUCTIONS
==========================

--- PART 1: Create a GitHub Account (skip if you have one) ---

1. Go to https://github.com
2. Click "Sign up"
3. Enter email, create password, choose username
4. Verify your email address
   (Takes about 2 minutes)


--- PART 2: Create a New Repository ---

1. Log into github.com
2. Click the GREEN "New" button (top left)
   OR go to: https://github.com/new

3. Fill in:
   - Repository name: revival-choir-songs
   - Description: Revival Choir Songs App (optional)
   - Select: PUBLIC  <-- Important! (free build minutes)
   - Leave everything else as default

4. Click "Create repository"


--- PART 3: Upload the App Files ---

1. On your new empty repository page, you will see:
   "uploading an existing file" link - click it

2. Drag ALL these files into the upload box:
     main.py
     songs_data.py
     buildozer.spec
     icon.png

3. Also upload the folder:
     .github/workflows/build.yml
   (You may need to create the folder path manually:
    Click "creating a new file", type:
    .github/workflows/build.yml
    then paste the contents of build.yml)

4. Scroll down, click "Commit changes"


--- PART 4: Upload the Workflow File ---

If the drag-and-drop did not include .github/workflows/build.yml:

1. On your repository, click "Add file" > "Create new file"
2. In the filename box type exactly:
   .github/workflows/build.yml
3. Open the build.yml file from this zip on your computer
4. Copy ALL its contents and paste into the editor
5. Click "Commit new file"


--- PART 5: Watch the Build ---

1. Click the "Actions" tab at the top of your repository
2. You will see "Build Revival Choir APK" running
   (yellow circle = running, green tick = done)
3. Wait 10-15 minutes
4. Click on the completed workflow run
5. Under "Artifacts" at the bottom, click:
   "RevivalChoirSongs-APK"
6. A ZIP file downloads - open it to find your APK!


--- PART 6: Install on Your Android Phone ---

1. Send the APK to your phone:
   - Email it to yourself and open on phone
   - WhatsApp it to yourself
   - Upload to Google Drive, open on phone
   - USB cable

2. On your phone:
   Settings > Security > Install unknown apps > Allow

3. Open the APK file on your phone
4. Tap "Install"
5. Revival Choir Songs appears on your home screen!


--- SHARING WITH OTHERS ---

Just send them the APK file.
They install it the same way (steps above).
The code is compiled and protected - nobody can view it.


NEED HELP?
==========
If the build fails, click on the failed workflow run
and scroll down to see the error message.
Most common fix: make sure all 4 files are uploaded correctly.
