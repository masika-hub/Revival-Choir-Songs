"""
Revival Choir Songs App - Kivy Android Application
Mighty Revival Choir  .  104 Songs
"""

import os, json, re
from functools import partial
from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen, SlideTransition, NoTransition
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.widget import Widget
from kivy.uix.popup import Popup
from kivy.graphics import Color, Rectangle, RoundedRectangle, Line
from kivy.metrics import dp, sp
from kivy.core.window import Window
from kivy.clock import Clock
from kivy.storage.jsonstore import JsonStore
from kivy.properties import StringProperty, NumericProperty, BooleanProperty, ListProperty
from songs_data import SONGS as DEFAULT_SONGS

# ---
LIGHT = {
    "bg":       (0.980, 0.961, 0.937, 1),
    "bg2":      (0.945, 0.910, 0.871, 1),
    "card":     (1,     1,     1,     1),
    "burg":     (0.290, 0.055, 0.165, 1),
    "burg2":    (0.180, 0.031, 0.094, 1),
    "gold":     (0.784, 0.573, 0.165, 1),
    "gold2":    (0.910, 0.722, 0.294, 1),
    "txt":      (0.102, 0.047, 0.078, 1),
    "txt2":     (0.420, 0.290, 0.353, 1),
    "txt3":     (0.604, 0.478, 0.541, 1),
    "border":   (0.878, 0.816, 0.753, 1),
}
DARK = {
    "bg":       (0.063, 0.031, 0.063, 1),
    "bg2":      (0.102, 0.063, 0.102, 1),
    "card":     (0.118, 0.063, 0.102, 1),
    "burg":     (0.784, 0.573, 0.165, 1),
    "burg2":    (0.220, 0.094, 0.165, 1),
    "gold":     (0.910, 0.722, 0.294, 1),
    "gold2":    (0.961, 0.816, 0.439, 1),
    "txt":      (0.941, 0.910, 0.925, 1),
    "txt2":     (0.690, 0.565, 0.627, 1),
    "txt3":     (0.502, 0.376, 0.439, 1),
    "border":   (0.231, 0.125, 0.200, 1),
}

store = JsonStore("revival_choir.json")


def get_songs():
    try:
        if store.exists("songs"):
            return store.get("songs")["data"]
    except Exception:
        pass
    return [dict(s) for s in DEFAULT_SONGS]


def save_songs(songs):
    store.put("songs", data=songs)


def get_theme():
    try:
        if store.exists("prefs"):
            return store.get("prefs").get("dark", False)
    except Exception:
        pass
    return False


def save_theme(dark):
    prefs = {}
    try:
        if store.exists("prefs"):
            prefs = dict(store.get("prefs"))
    except Exception:
        pass
    prefs["dark"] = dark
    store.put("prefs", **prefs)


def get_fontsize():
    try:
        if store.exists("prefs"):
            return store.get("prefs").get("fontsize", 15)
    except Exception:
        pass
    return 15


def save_fontsize(size):
    prefs = {}
    try:
        if store.exists("prefs"):
            prefs = dict(store.get("prefs"))
    except Exception:
        pass
    prefs["fontsize"] = size
    store.put("prefs", **prefs)


# Global state
SONGS = get_songs()
DARK_MODE = get_theme()
FONT_SIZE = get_fontsize()


def C(key):
    return DARK[key] if DARK_MODE else LIGHT[key]


def rgb(t):
    return t[0], t[1], t[2]


# ---

def draw_rect(widget, color, radius=0):
    widget.canvas.before.clear()
    with widget.canvas.before:
        Color(*color)
        if radius:
            RoundedRectangle(pos=widget.pos, size=widget.size, radius=[dp(radius)])
        else:
            Rectangle(pos=widget.pos, size=widget.size)


def bind_bg(widget, color, radius=0):
    def _draw(*a):
        draw_rect(widget, color, radius)
    widget.bind(pos=_draw, size=_draw)
    _draw()


# ---

class ThemedLabel(Label):
    def __init__(self, color_key="txt", **kw):
        super().__init__(**kw)
        self.color_key = color_key
        self.color = C(color_key)
        self.markup = True

    def refresh(self):
        self.color = C(self.color_key)


class ThemedButton(Button):
    def __init__(self, bg_key="burg", fg=(1, 1, 1, 1), radius=10, **kw):
        super().__init__(**kw)
        self.bg_key = bg_key
        self.fg = fg
        self.radius = radius
        self.background_color = (0, 0, 0, 0)
        self.background_normal = ""
        self.color = fg
        self.font_size = sp(14)
        self.bold = True
        bind_bg(self, C(bg_key), radius)

    def refresh(self):
        draw_rect(self, C(self.bg_key), self.radius)


class Header(BoxLayout):
    """Burgundy top header with title and optional right button."""

    def __init__(self, title="Revival Choir", right_widget=None, **kw):
        super().__init__(orientation="horizontal", size_hint_y=None,
                         height=dp(56), padding=[dp(8), 0], spacing=dp(4), **kw)
        self._title_lbl = ThemedLabel(
            text=title, color_key="bg",
            font_size=sp(17), bold=True, halign="left", valign="middle",
            size_hint_x=1,
        )
        self._title_lbl.bind(size=self._title_lbl.setter("text_size"))
        self.add_widget(self._title_lbl)
        if right_widget:
            self.add_widget(right_widget)
        bind_bg(self, C("burg"))

    def set_title(self, t):
        self._title_lbl.text = t

    def refresh(self):
        draw_rect(self, C("burg"))
        self._title_lbl.color = C("bg")


class SongCard(BoxLayout):
    """One song row card."""

    def __init__(self, song, on_tap, query="", **kw):
        super().__init__(orientation="horizontal", size_hint_y=None,
                         height=dp(68), spacing=0, **kw)
        self.song = song
        self.padding = [0, 0, 0, 0]

        # Number box
        num_box = BoxLayout(size_hint_x=None, width=dp(56))
        bind_bg(num_box, C("burg"))
        num_lbl = ThemedLabel(
            text=str(song["num"]), color_key="gold",
            font_size=sp(16), bold=True, halign="center", valign="middle",
            size_hint=(1, 1),
        )
        num_lbl.bind(size=num_lbl.setter("text_size"))
        num_box.add_widget(num_lbl)
        self.add_widget(num_box)

        # Body
        body = BoxLayout(orientation="vertical", padding=[dp(12), dp(8)], spacing=dp(2))
        bind_bg(body, C("card"))

        title_text = song["title"]
        if query:
            esc_q = re.escape(query)
            title_text = re.sub(f"({esc_q})", r"[color=C8922A]\1[/color]",
                                title_text, flags=re.IGNORECASE)

        title_lbl = ThemedLabel(
            text=title_text, color_key="txt",
            font_size=sp(13.5), bold=True,
            halign="left", valign="middle", size_hint_y=0.55,
        )
        title_lbl.bind(size=title_lbl.setter("text_size"))

        preview_lines = [l.strip() for l in song["lyrics"].split("\n")
                         if l.strip() and not re.match(r"^(verse|chorus|bridge|\d+\.?$)", l.strip(), re.I)]
        preview_text = "  .  ".join(preview_lines[:2])[:70]
        prev_lbl = ThemedLabel(
            text=preview_text, color_key="txt3",
            font_size=sp(11), halign="left", valign="middle", size_hint_y=0.45,
        )
        prev_lbl.bind(size=prev_lbl.setter("text_size"))

        body.add_widget(title_lbl)
        body.add_widget(prev_lbl)
        self.add_widget(body)

        # Arrow
        arr = BoxLayout(size_hint_x=None, width=dp(30))
        bind_bg(arr, C("card"))
        arr_lbl = ThemedLabel(text=">", color_key="txt3", font_size=sp(22),
                              halign="center", valign="middle")
        arr_lbl.bind(size=arr_lbl.setter("text_size"))
        arr.add_widget(arr_lbl)
        self.add_widget(arr)

        # Border bottom
        with self.canvas.after:
            Color(*C("border"))
            self._border = Line(points=[dp(56), 0, self.width, 0], width=1)

        self.bind(size=self._update_border)

        # Touch
        btn = Button(size_hint=(1, 1), background_color=(0, 0, 0, 0),
                     background_normal="", on_release=lambda *a: on_tap(song["num"]))
        btn.pos = self.pos
        btn.bind(pos=self.setter("pos"))
        self.add_widget(btn)

    def _update_border(self, *a):
        self._border.points = [dp(56), 1, self.width, 1]


class TabBar(BoxLayout):
    """Bottom tab bar with 4 tabs."""

    TABS = [
        ("num", "# 1-104", "="),
        ("az", "A - Z", "A"),
        ("srch", "Search", "Search"),
        ("edit", "Edit Songs", "[edit]"),
    ]

    def __init__(self, on_switch, **kw):
        super().__init__(orientation="horizontal", size_hint_y=None,
                         height=dp(54), **kw)
        self.on_switch = on_switch
        self._btns = {}
        self._active = "num"
        bind_bg(self, C("burg2"))

        for key, label, icon in self.TABS:
            col = BoxLayout(orientation="vertical", padding=[dp(2), dp(6)], spacing=0)
            btn = Button(
                text=f"{icon}\n{label}",
                background_color=(0, 0, 0, 0),
                background_normal="",
                color=(*rgb(C("txt3")), 1),
                font_size=sp(9), bold=True,
                halign="center",
                on_release=partial(self._tap, key),
            )
            col.add_widget(btn)
            self._btns[key] = btn
            self.add_widget(col)

        self._highlight("num")

    def _tap(self, key, *a):
        if key != self._active:
            self._active = key
            self._highlight(key)
            self.on_switch(key)

    def _highlight(self, key):
        for k, btn in self._btns.items():
            if k == key:
                btn.color = (*rgb(C("gold2")), 1)
            else:
                btn.color = (*rgb(C("txt3")), 0.7)

    def refresh(self):
        draw_rect(self, C("burg2"))
        self._highlight(self._active)


# ---

class MainScreen(Screen):
    """The primary screen: numbered list, A-Z, search, and song manager."""

    def __init__(self, app, **kw):
        super().__init__(name="main", **kw)
        self.app = app
        self.current_tab = "num"

        root = BoxLayout(orientation="vertical")
        bind_bg(root, C("bg"))

        # Header
        self.hdr = Header("+  Revival Choir Songs")
        # Theme toggle button
        theme_btn = Button(
            text="Dark" if not DARK_MODE else "Light",
            size_hint=(None, None), size=(dp(44), dp(44)),
            background_color=(0, 0, 0, 0), background_normal="",
            color=(1, 1, 1, 1), font_size=sp(18),
            on_release=lambda *a: self.app.toggle_theme(),
        )
        self.hdr.add_widget(theme_btn)
        self.theme_btn = theme_btn
        root.add_widget(self.hdr)

        # Sub-header count
        self.count_lbl = ThemedLabel(
            text="104 Songs  .  #1 - #104",
            color_key="txt2", font_size=sp(11),
            size_hint_y=None, height=dp(20),
            halign="center", valign="middle",
        )
        self.count_lbl.bind(size=self.count_lbl.setter("text_size"))
        bind_bg_row = BoxLayout(size_hint_y=None, height=dp(22))
        bind_bg(bind_bg_row, C("burg2"))
        bind_bg_row.add_widget(self.count_lbl)
        root.add_widget(bind_bg_row)
        self.count_row = bind_bg_row

        # Search bar (shown only in search tab)
        self.srch_wrap = BoxLayout(orientation="vertical", size_hint_y=None,
                                   height=dp(54), padding=[dp(10), dp(6)], opacity=0)
        self.srch_input = TextInput(
            hint_text="Search title or lyrics...",
            multiline=False, size_hint_y=None, height=dp(40),
            background_color=C("card"),
            foreground_color=C("txt"),
            cursor_color=C("burg"),
            font_size=sp(14),
        )
        self.srch_input.bind(text=self._on_search)
        self.srch_wrap.add_widget(self.srch_input)
        root.add_widget(self.srch_wrap)

        # Scroll area
        self.scroll = ScrollView(do_scroll_x=False, bar_width=dp(3))
        self.list_layout = GridLayout(cols=1, spacing=dp(2),
                                       size_hint_y=None, padding=[dp(6), dp(4)])
        self.list_layout.bind(minimum_height=self.list_layout.setter("height"))
        self.scroll.add_widget(self.list_layout)
        root.add_widget(self.scroll)

        # Tab bar
        self.tab_bar = TabBar(self._switch_tab)
        root.add_widget(self.tab_bar)

        self.add_widget(root)
        self._root_layout = root
        Clock.schedule_once(lambda dt: self.render_num(), 0.05)

    def _switch_tab(self, tab):
        self.current_tab = tab
        self.srch_wrap.opacity = 1 if tab == "srch" else 0
        self.srch_wrap.height = dp(54) if tab == "srch" else 0
        if tab == "num":
            self.render_num()
        elif tab == "az":
            self.render_az()
        elif tab == "srch":
            self.render_search(self.srch_input.text)
            self.srch_input.focus = True
        elif tab == "edit":
            self.render_mgmt()

    def _on_search(self, inst, val):
        if self.current_tab == "srch":
            self.render_search(val)

    def _clear_list(self):
        self.list_layout.clear_widgets()
        self.scroll.scroll_y = 1

    def _add_card(self, song, query=""):
        card = SongCard(song, self._open_song, query=query)
        self.list_layout.add_widget(card)

    def _section_label(self, text):
        box = BoxLayout(size_hint_y=None, height=dp(36), padding=[dp(8), dp(4)])
        bind_bg(box, C("bg2"))
        lbl = ThemedLabel(
            text=text, color_key="burg",
            font_size=sp(16), bold=True,
            halign="left", valign="middle",
        )
        lbl.bind(size=lbl.setter("text_size"))
        box.add_widget(lbl)
        return box

    def _empty_label(self, text):
        lbl = ThemedLabel(
            text=text, color_key="txt3",
            font_size=sp(14), halign="center", valign="middle",
            size_hint_y=None, height=dp(200),
        )
        lbl.bind(size=lbl.setter("text_size"))
        return lbl

    def render_num(self):
        self._clear_list()
        for song in sorted(SONGS, key=lambda s: s["num"]):
            self._add_card(song)
        self._update_count()

    def render_az(self):
        self._clear_list()
        sorted_s = sorted(SONGS, key=lambda s: s["title"].strip().upper())
        last = ""
        for song in sorted_s:
            fl = next((c.upper() for c in song["title"] if c.isalpha()), "#")
            if fl != last:
                self.list_layout.add_widget(self._section_label(fl))
                last = fl
            self._add_card(song)

    def render_search(self, query):
        self._clear_list()
        q = query.strip().lower()
        if not q:
            self.list_layout.add_widget(
                self._empty_label("Type a song title or any word from the lyrics")
            )
            return
        results = [s for s in SONGS
                   if q in s["title"].lower() or q in s["lyrics"].lower()]
        results.sort(key=lambda s: (0 if q in s["title"].lower() else 1, s["num"]))
        if results:
            hint = ThemedLabel(
                text=f"{len(results)} result{'s' if len(results)!=1 else ''} found",
                color_key="txt3", font_size=sp(11),
                size_hint_y=None, height=dp(24),
                halign="center", valign="middle",
            )
            hint.bind(size=hint.setter("text_size"))
            self.list_layout.add_widget(hint)
            for song in results:
                self._add_card(song, query=query.strip())
        else:
            self.list_layout.add_widget(
                self._empty_label(f'No results for "{query}"')
            )

    def render_mgmt(self):
        self._clear_list()
        # Add New Song button
        add_btn = ThemedButton(
            text="+ Add New Song", bg_key="burg",
            size_hint_y=None, height=dp(48),
        )
        add_btn.bind(on_release=lambda *a: self.app.open_edit(None))
        self.list_layout.add_widget(add_btn)

        # Info box
        info = ThemedLabel(
            text=("[color={}]Song Manager[/color]\n"
                  "Tap [b]Edit[/b] to update a song. Tap [b]Del[/b] to delete.\n"
                  "All changes saved offline on this device.").format(
                "4A0E2A" if not DARK_MODE else "C8922A"),
            color_key="txt2", font_size=sp(11.5),
            halign="left", valign="top",
            size_hint_y=None, height=dp(64),
        )
        info.bind(size=info.setter("text_size"))
        info_box = BoxLayout(size_hint_y=None, height=dp(68), padding=[dp(10), dp(4)])
        bind_bg(info_box, C("bg2"))
        info_box.add_widget(info)
        self.list_layout.add_widget(info_box)

        for song in sorted(SONGS, key=lambda s: s["num"]):
            row = self._mgmt_row(song)
            self.list_layout.add_widget(row)

    def _mgmt_row(self, song):
        row = BoxLayout(orientation="horizontal", size_hint_y=None,
                        height=dp(52), padding=[dp(6), dp(6)], spacing=dp(6))
        bind_bg(row, C("card"))

        num_lbl = ThemedLabel(
            text=str(song["num"]), color_key="burg",
            font_size=sp(14), bold=True,
            size_hint_x=None, width=dp(40),
            halign="center", valign="middle",
        )
        num_lbl.bind(size=num_lbl.setter("text_size"))
        row.add_widget(num_lbl)

        title_lbl = ThemedLabel(
            text=song["title"], color_key="txt",
            font_size=sp(12.5), bold=True,
            halign="left", valign="middle", size_hint_x=1,
        )
        title_lbl.bind(size=title_lbl.setter("text_size"))
        row.add_widget(title_lbl)

        edit_btn = ThemedButton(
            text="Edit", bg_key="burg",
            size_hint=(None, None), size=(dp(48), dp(36)),
            font_size=sp(12),
        )
        edit_btn.bind(on_release=lambda *a, s=song: self.app.open_edit(s["num"]))
        row.add_widget(edit_btn)

        del_btn = Button(
            text="Del",
            background_color=(0.75, 0.22, 0.17, 1),
            background_normal="",
            color=(1, 1, 1, 1),
            size_hint=(None, None), size=(dp(44), dp(36)),
            font_size=sp(12), bold=True,
        )
        del_btn.bind(on_release=lambda *a, s=song: self.app.confirm_delete(s["num"]))
        row.add_widget(del_btn)

        sep = Widget(size_hint_y=None, height=dp(1))
        with sep.canvas:
            Color(*C("border"))
            Rectangle(pos=sep.pos, size=sep.size)
        sep.bind(pos=lambda w, p: setattr(w, 'pos', p),
                 size=lambda w, s: [w.canvas.clear(),
                                    Color(*C("border")).__class__.__init__(Color(*C("border"))),
                                    Rectangle(pos=w.pos, size=w.size)])
        return row

    def _open_song(self, num):
        self.app.open_song(num)

    def _update_count(self):
        n = len(SONGS)
        nums = sorted(s["num"] for s in SONGS)
        lo, hi = nums[0], nums[-1]
        self.count_lbl.text = f"{n} Songs   .   #{lo} - #{hi}"

    def refresh_theme(self):
        self.theme_btn.text = "Light" if DARK_MODE else "Dark"
        draw_rect(self._root_layout, C("bg"))
        self.hdr.refresh()
        draw_rect(self.count_row, C("burg2"))
        self.count_lbl.refresh()
        self.tab_bar.refresh()
        self.srch_input.background_color = C("card")
        self.srch_input.foreground_color = C("txt")
        # Re-render current tab
        if self.current_tab == "num":
            self.render_num()
        elif self.current_tab == "az":
            self.render_az()
        elif self.current_tab == "srch":
            self.render_search(self.srch_input.text)
        elif self.current_tab == "edit":
            self.render_mgmt()


class DetailScreen(Screen):
    """Full-screen song lyrics view."""

    def __init__(self, app, **kw):
        super().__init__(name="detail", **kw)
        self.app = app
        self._song = None

        root = BoxLayout(orientation="vertical")
        bind_bg(root, C("bg"))

        # Header with back + font controls
        hdr_row = BoxLayout(orientation="horizontal", size_hint_y=None,
                            height=dp(56), padding=[dp(4), 0], spacing=dp(4))
        bind_bg(hdr_row, C("burg"))

        back_btn = Button(
            text="BACK", font_size=sp(26), bold=True,
            color=(1, 1, 1, 1), size_hint=(None, 1), width=dp(44),
            background_color=(0, 0, 0, 0), background_normal="",
            on_release=lambda *a: self.app.go_back(),
        )
        hdr_row.add_widget(back_btn)

        self.hdr_title = ThemedLabel(
            text="", color_key="bg",
            font_size=sp(14), bold=True,
            halign="center", valign="middle", size_hint_x=1,
        )
        self.hdr_title.bind(size=self.hdr_title.setter("text_size"))
        hdr_row.add_widget(self.hdr_title)

        fdn = Button(text="A-", size_hint=(None, None), size=(dp(38), dp(36)),
                     background_color=(0, 0, 0, 0.25), background_normal="",
                     color=(1, 1, 1, 1), font_size=sp(13), bold=True,
                     on_release=lambda *a: self._change_font(-1))
        fup = Button(text="A+", size_hint=(None, None), size=(dp(38), dp(36)),
                     background_color=(0, 0, 0, 0.25), background_normal="",
                     color=(1, 1, 1, 1), font_size=sp(13), bold=True,
                     on_release=lambda *a: self._change_font(1))
        hdr_row.add_widget(fdn)
        hdr_row.add_widget(fup)

        root.add_widget(hdr_row)
        self._hdr_row = hdr_row

        # Scroll content
        self.scroll = ScrollView(do_scroll_x=False, bar_width=dp(3))
        self.content = GridLayout(cols=1, size_hint_y=None, spacing=0,
                                   padding=[dp(14), dp(8)])
        self.content.bind(minimum_height=self.content.setter("height"))

        # Big number
        self.num_lbl = ThemedLabel(
            text="", color_key="burg",
            font_size=sp(72), bold=True,
            halign="center", valign="middle",
            size_hint_y=None, height=dp(90),
        )
        self.num_lbl.bind(size=self.num_lbl.setter("text_size"))

        # Gold divider
        self._divider = Widget(size_hint_y=None, height=dp(3))
        with self._divider.canvas:
            Color(*C("gold"))
            self._div_rect = Rectangle(pos=self._divider.pos, size=self._divider.size)
        self._divider.bind(pos=self._update_div, size=self._update_div)

        # Song title
        self.title_lbl = ThemedLabel(
            text="", color_key="txt",
            font_size=sp(17), bold=True,
            halign="center", valign="middle",
            size_hint_y=None, height=dp(52),
        )
        self.title_lbl.bind(size=self.title_lbl.setter("text_size"))

        # Lyrics
        self.lyrics_lbl = ThemedLabel(
            text="", color_key="txt",
            font_size=sp(FONT_SIZE),
            halign="left", valign="top",
            size_hint_y=None,
        )
        self.lyrics_lbl.bind(
            size=self.lyrics_lbl.setter("text_size"),
            texture_size=lambda w, ts: setattr(w, "height", ts[1] + dp(20)),
        )

        self.content.add_widget(self.num_lbl)
        self.content.add_widget(self._divider)
        self.content.add_widget(self.title_lbl)
        self.content.add_widget(self.lyrics_lbl)
        self.scroll.add_widget(self.content)
        root.add_widget(self.scroll)

        self.add_widget(root)
        self._root_layout = root

    def _update_div(self, *a):
        self._div_rect.pos = self._divider.pos
        self._div_rect.size = (min(dp(60), self._divider.width), self._divider.height)

    def load_song(self, song):
        self._song = song
        self.hdr_title.text = song["title"]
        self.num_lbl.text = str(song["num"])
        self.title_lbl.text = song["title"].upper()
        self.lyrics_lbl.text = self._format_lyrics(song["lyrics"])
        self.lyrics_lbl.font_size = sp(FONT_SIZE)
        self.scroll.scroll_y = 1

    def _format_lyrics(self, raw):
        section_re = re.compile(
            r"^(verse\s*(one|two|three|four|five|\d+)?|chorus\s*\d*|bridge\s*\d*|"
            r"pre-chorus|outro|intro|\d+\.)$", re.IGNORECASE
        )
        lines = []
        col = "4A0E2A" if not DARK_MODE else "C8922A"
        for line in raw.split("\n"):
            t = line.strip()
            if t and section_re.match(t):
                lines.append(f"\n[b][color={col}]{t.upper()}[/color][/b]")
            else:
                lines.append(line)
        return "\n".join(lines)

    def _change_font(self, delta):
        global FONT_SIZE
        FONT_SIZE = max(10, min(24, FONT_SIZE + delta))
        save_fontsize(FONT_SIZE)
        self.lyrics_lbl.font_size = sp(FONT_SIZE)

    def refresh_theme(self):
        draw_rect(self._root_layout, C("bg"))
        draw_rect(self._hdr_row, C("burg"))
        self.hdr_title.color = C("bg")
        self.num_lbl.color = C("burg")
        self.title_lbl.color = C("txt")
        if self._song:
            self.lyrics_lbl.text = self._format_lyrics(self._song["lyrics"])
        self.lyrics_lbl.color = C("txt")


class EditScreen(Screen):
    """Add or edit a song."""

    def __init__(self, app, **kw):
        super().__init__(name="edit", **kw)
        self.app = app
        self.editing_num = None

        root = BoxLayout(orientation="vertical")
        bind_bg(root, C("bg"))

        # Header
        hdr_row = BoxLayout(orientation="horizontal", size_hint_y=None,
                            height=dp(56), padding=[dp(4), 0], spacing=dp(4))
        bind_bg(hdr_row, C("burg"))
        back_btn = Button(
            text="BACK", font_size=sp(26), bold=True,
            color=(1, 1, 1, 1), size_hint=(None, 1), width=dp(44),
            background_color=(0, 0, 0, 0), background_normal="",
            on_release=lambda *a: self.app.go_back(),
        )
        hdr_row.add_widget(back_btn)
        self.hdr_title = ThemedLabel(
            text="Edit Song", color_key="bg",
            font_size=sp(15), bold=True,
            halign="center", valign="middle", size_hint_x=1,
        )
        self.hdr_title.bind(size=self.hdr_title.setter("text_size"))
        hdr_row.add_widget(self.hdr_title)
        save_btn = Button(
            text="SAVE", font_size=sp(13), bold=True,
            color=(1, 1, 1, 1), size_hint=(None, 1), width=dp(70),
            background_color=(0, 0, 0, 0.3), background_normal="",
            on_release=lambda *a: self.do_save(),
        )
        hdr_row.add_widget(save_btn)
        root.add_widget(hdr_row)
        self._hdr_row = hdr_row

        # Form in scroll
        scroll = ScrollView(do_scroll_x=False, bar_width=dp(3))
        form = GridLayout(cols=1, size_hint_y=None,
                          spacing=dp(10), padding=[dp(12), dp(12)])
        form.bind(minimum_height=form.setter("height"))

        def field_label(text):
            lbl = ThemedLabel(
                text=text, color_key="burg",
                font_size=sp(11), bold=True,
                halign="left", valign="middle",
                size_hint_y=None, height=dp(22),
            )
            lbl.bind(size=lbl.setter("text_size"))
            return lbl

        form.add_widget(field_label("SONG NUMBER"))
        self.num_input = TextInput(
            hint_text="e.g. 105", multiline=False,
            input_filter="int",
            size_hint_y=None, height=dp(44),
            background_color=C("card"),
            foreground_color=C("txt"),
            font_size=sp(15),
        )
        form.add_widget(self.num_input)

        form.add_widget(field_label("SONG TITLE"))
        self.title_input = TextInput(
            hint_text="e.g. AMAZING GRACE", multiline=False,
            size_hint_y=None, height=dp(44),
            background_color=C("card"),
            foreground_color=C("txt"),
            font_size=sp(15),
        )
        form.add_widget(self.title_input)

        form.add_widget(field_label("LYRICS"))
        self.lyrics_input = TextInput(
            hint_text="Type full lyrics here...\n\nVERSE ONE\n...\n\nCHORUS\n...",
            multiline=True,
            size_hint_y=None, height=dp(320),
            background_color=C("card"),
            foreground_color=C("txt"),
            font_size=sp(13),
        )
        form.add_widget(self.lyrics_input)

        # Save button
        self.save_btn = ThemedButton(
            text="Save Changes", bg_key="burg",
            size_hint_y=None, height=dp(50),
        )
        self.save_btn.bind(on_release=lambda *a: self.do_save())
        form.add_widget(self.save_btn)

        # Delete button (hidden for new songs)
        self.del_btn = Button(
            text="Delete This Song",
            background_color=(0.75, 0.22, 0.17, 1),
            background_normal="",
            color=(1, 1, 1, 1),
            size_hint_y=None, height=dp(46),
            font_size=sp(14), bold=True,
            opacity=0,
        )
        self.del_btn.bind(on_release=lambda *a: self.app.confirm_delete(self.editing_num))
        form.add_widget(self.del_btn)

        scroll.add_widget(form)
        root.add_widget(scroll)
        self.add_widget(root)
        self._root_layout = root
        self._form = form
        self._inputs = [self.num_input, self.title_input, self.lyrics_input]

    def load_song(self, num):
        self.editing_num = num
        if num is None:
            self.hdr_title.text = "Add New Song"
            self.num_input.text = ""
            self.title_input.text = ""
            self.lyrics_input.text = ""
            self.del_btn.opacity = 0
            self.del_btn.disabled = True
        else:
            song = next((s for s in SONGS if s["num"] == num), None)
            if song:
                self.hdr_title.text = f"Edit Song #{num}"
                self.num_input.text = str(song["num"])
                self.title_input.text = song["title"]
                self.lyrics_input.text = song["lyrics"]
                self.del_btn.opacity = 1
                self.del_btn.disabled = False

    def do_save(self):
        global SONGS
        try:
            num = int(self.num_input.text.strip())
        except ValueError:
            self._alert("Please enter a valid song number.")
            return
        title = self.title_input.text.strip()
        lyrics = self.lyrics_input.text.strip()
        if num < 1:
            self._alert("Song number must be 1 or greater.")
            return
        if not title:
            self._alert("Please enter a song title.")
            return
        if not lyrics:
            self._alert("Please enter the lyrics.")
            return

        # Check for number conflict
        if self.editing_num is None or num != self.editing_num:
            conflict = next((s for s in SONGS if s["num"] == num), None)
            if conflict:
                self._alert(f"Song #{num} already exists:\n{conflict['title']}\n\nUse a different number.")
                return

        # Remove old entry if editing
        if self.editing_num is not None:
            SONGS = [s for s in SONGS if s["num"] != self.editing_num]

        # Add/update
        existing = next((i for i, s in enumerate(SONGS) if s["num"] == num), None)
        if existing is not None:
            SONGS[existing] = {"num": num, "title": title, "lyrics": lyrics}
        else:
            SONGS.append({"num": num, "title": title, "lyrics": lyrics})
        SONGS.sort(key=lambda s: s["num"])
        save_songs(SONGS)
        self.app.go_back()
        self.app.main_screen.render_mgmt()

    def _alert(self, msg):
        content = BoxLayout(orientation="vertical", padding=dp(16), spacing=dp(12))
        lbl = Label(text=msg, color=C("txt"), font_size=sp(14),
                    halign="center", valign="middle")
        lbl.bind(size=lbl.setter("text_size"))
        ok = Button(text="OK", size_hint_y=None, height=dp(44),
                    background_color=C("burg"), background_normal="",
                    color=(1, 1, 1, 1), font_size=sp(14), bold=True)
        content.add_widget(lbl)
        content.add_widget(ok)
        popup = Popup(title="", content=content,
                      size_hint=(0.85, None), height=dp(200),
                      separator_height=0,
                      background_color=C("card"))
        ok.bind(on_release=popup.dismiss)
        popup.open()

    def refresh_theme(self):
        draw_rect(self._root_layout, C("bg"))
        draw_rect(self._hdr_row, C("burg"))
        self.hdr_title.color = C("bg")
        for inp in self._inputs:
            inp.background_color = C("card")
            inp.foreground_color = C("txt")
        draw_rect(self.save_btn, C("burg"), 10)


# ---

class RevivalChoirApp(App):
    title = "Revival Choir Songs"

    def build(self):
        Window.clearcolor = C("bg")
        self.sm = ScreenManager(transition=SlideTransition(duration=0.2))
        self.main_screen = MainScreen(self)
        self.detail_screen = DetailScreen(self)
        self.edit_screen = EditScreen(self)
        self.sm.add_widget(self.main_screen)
        self.sm.add_widget(self.detail_screen)
        self.sm.add_widget(self.edit_screen)
        return self.sm

    def open_song(self, num):
        song = next((s for s in SONGS if s["num"] == num), None)
        if song:
            self.detail_screen.load_song(song)
            self.sm.transition.direction = "left"
            self.sm.current = "detail"

    def open_edit(self, num):
        self.edit_screen.load_song(num)
        self.sm.transition.direction = "left"
        self.sm.current = "edit"

    def go_back(self):
        self.sm.transition.direction = "right"
        self.sm.current = "main"

    def toggle_theme(self):
        global DARK_MODE
        DARK_MODE = not DARK_MODE
        save_theme(DARK_MODE)
        Window.clearcolor = C("bg")
        self.main_screen.refresh_theme()
        self.detail_screen.refresh_theme()
        self.edit_screen.refresh_theme()

    def confirm_delete(self, num):
        global SONGS
        song = next((s for s in SONGS if s["num"] == num), None)
        if not song:
            return
        content = BoxLayout(orientation="vertical", padding=dp(16), spacing=dp(12))
        lbl = Label(
            text=f"Delete #{num} {song['title']}?\n\nThis cannot be undone.",
            color=C("txt"), font_size=sp(14),
            halign="center", valign="middle",
        )
        lbl.bind(size=lbl.setter("text_size"))
        btn_row = BoxLayout(spacing=dp(10), size_hint_y=None, height=dp(44))
        cancel = Button(text="Cancel", background_color=C("bg2"),
                        background_normal="", color=C("txt"),
                        font_size=sp(14), bold=True)
        confirm = Button(text="Delete", background_color=(0.75, 0.22, 0.17, 1),
                         background_normal="", color=(1, 1, 1, 1),
                         font_size=sp(14), bold=True)
        btn_row.add_widget(cancel)
        btn_row.add_widget(confirm)
        content.add_widget(lbl)
        content.add_widget(btn_row)
        popup = Popup(title="", content=content,
                      size_hint=(0.88, None), height=dp(220),
                      separator_height=0,
                      background_color=C("card"))

        def do_delete(*a):
            global SONGS
            SONGS = [s for s in SONGS if s["num"] != num]
            save_songs(SONGS)
            popup.dismiss()
            self.go_back()
            self.main_screen.render_mgmt()

        cancel.bind(on_release=popup.dismiss)
        confirm.bind(on_release=do_delete)
        popup.open()


if __name__ == "__main__":
    RevivalChoirApp().run()
